<template>
    <div>
            <iv-DraggableDiv name="Control Panel 1" idName="Control Panel 1">
                <iv-slider name="Probe Line Rotation Angle:" :min=0 :max=360 :tick_step=60 :step=1 :init_val=0 @sliderChanged="sliderChange" v-if="sliderActive"></iv-slider>
                <br>
                <center>
                    <iv-button style="display: inline-block; width: 40%; margin-right:5px;" @click="buttonPress" v-if="buttonActive">{{ buttonText }}</iv-button>
                    <iv-button style="display: inline-block; width: 40%; margin-right:20px;" @click="resetPress" v-if="!buttonActive">Reset</iv-button>
                </center>
                <center style="position:relative;">
                      <h5>Transformation Matrix:</h5>
                      <table class="matrix" style="position:relative; top:0px">
                        <tbody>
                            <tr>
                                <td><input v-model="M0" @change="matrixUpdate" :disabled="!sliderActive"> </td>
                                <td><input v-model="M1" @change="matrixUpdate" :disabled="!sliderActive"> </td></tr>
                                <tr><td><input v-model="M2" @change="matrixUpdate" :disabled="!sliderActive"> </td>
                                <td><input v-model="M3" @change="matrixUpdate" :disabled="!sliderActive"> </td>
                            </tr>
                        </tbody>
                      </table>
                </center>
            </iv-DraggableDiv>
        <iv-visualisation :title="projectName">


            <template #hotspots>
                <iv-pane position="left">
                    <iv-sidebar-content>
                        <iv-sidebar-section title="Eigenvector Intuition">
                            When you multiply a matrix by a vector, a new <em>transformed</em> vector is produced. In this
                            visualisation, you can set your own 2x2 matrix and see how it transforms all points (i.e. position
                            vectors) in 2D space.
                            <br><br>
                        
                        
                            The eigenvectors of a matrix are vectors whose direction do not change under the matrix
                            transformation.
                            Position vectors along the span (direction) of the eigenvectors remain on the same line, i.e.
                            they do not change direction, after they are transformed by a matrix.
                            <br><br>

                            The eigenvalue is the scaling factor by which each position vector along the eigenvector span is
                            stretched.
                            
                            <br><br>
                        </iv-sidebar-section>
                        <iv-sidebar-section title="Instructions">
                            Set your matrix, and you can see the corresponding eigenvectors and eigenvalues for the matrix are:
                            <br><br>
                            <div class="row">
                                <div class="six columns" style="color: #02893B; font-weight: bold">Eigenvector 1:  {{ eigenvector1 }} <br> EigenValue 1: {{eigenvalue1}}</div>
                                <div class="six columns" style="color: #EC7300; font-weight: bold">Eigenvector 2:  {{ eigenvector2 }} <br> EigenValue 2: {{eigenvalue2}}</div>
                            </div>
                            <br>
                            Align the probe line with the eigenvector lines, then apply the transformation.
                            Notice how then the position vectors always remain on the same line.
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                <iv-toggle-hotspot position="bottom" title="Controls" idName="Control Panel 1" :draggable=true>
                    
                </iv-toggle-hotspot>
            </template>




            <div class="iv-welcome-message">
                <div id="graph" style="width: 100%; height: 60vh"></div>
            </div>
        </iv-visualisation>
    </div>
</template>
<script>
import Plotly from 'plotly.js/dist/plotly.min.js';
import $ from 'jquery';
import numeric from 'numeric';
import math from 'math';

export default {
    name:"App",
    data(){
        return {
            projectName: "Interpreting Eigenvectors",
            eigenvector1: "(2,0)",
            eigenvector2: "(2,0)",
            eigenvalue1: "1",
            eigenvalue2: "2",
            slider: 0,
            M0: 1,
            M1: 1,
            M2: 1,
            M3: 0,
            redraw: true,
            buttonText: "Apply",
            isPlaying: false,
            buttonActive: true,
            reset: false,
            sliderActive: true,
        }
    },
    methods: {
        sliderChange(e){
            this.redraw = true;
            this.slider = e;
        },
        matrixUpdate(){
            this.redraw = true;
        },
        buttonPress(){
            this.isPlaying = !this.isPlaying;
            this.sliderActive = false;
        },
        resetPress(){
            this.buttonActive = true;
            this.reset = true;
            this.sliderActive = true;
        }
    },
    mounted(){
        let vm = this;

        let theta0 = 0;
        let theta1 = 0;

        // Now begins the maths Segment of the code
        //function that copies an array
        function copy(arr) {
            let new_arr = arr.slice(0);
            for (let i = new_arr.length; i--;)
                if (new_arr[i] instanceof Array)
                    new_arr[i] = copy(new_arr[i]);
            return new_arr;
        }

        //calculates all the new data to be plotted using a transformation matrix and the probe's angle
        function calculate_positions_and_vectors(inputTheta, x1, y1, x2, y2) {
            let newTheta = inputTheta;
            let matrix = [[x1, y1], [x2, y2]];
            const rho = 15;
            let xArray = [];
            let yArray = [];

            let xArrayTrans = [];
            let yArrayTrans = [];

            //determine the eigenvectors:
            let xEigVector0 = numeric.eig(matrix).E.x[0][0];
            let yEigVector0 = numeric.eig(matrix).E.x[1][0];
            theta0 = Math.atan2(yEigVector0, xEigVector0);

            let xEigVector1 = numeric.eig(matrix).E.x[0][1];
            let yEigVector1 = numeric.eig(matrix).E.x[1][1];
            theta1 = Math.atan2(yEigVector1, xEigVector1);

            //generate points on the input line.
            let xInput = [];
            let yInput = [];
            let xInputTransformedArray = [];
            let yInputTransformedArray = [];

        

            let eigenvalue0 = 5 * math.round(numeric.eig(matrix).lambda.x[0] * 100) / 100;
            let eigenvalue1 = 5 * math.round(numeric.eig(matrix).lambda.x[1] * 100) / 100;
            let lineLength;
            if (eigenvalue0 >= eigenvalue1) {
                lineLength = eigenvalue0;
            } else {
                lineLength = eigenvalue1;
            }

            //defining input line:
            if (lineLength < rho) {
                lineLength = rho;
            }
            //generate eigenvector lines, line of input and transformed points.
            for (
                let x = -lineLength * 1.2;
                x < lineLength * 1.2 + 1.2;
                x += (lineLength * 1.2) / 10
            ) {
                for (
                    let y = -lineLength * 1.2;
                    y < lineLength * 1.2 + 1.2;
                    y += (lineLength * 1.2) / 10
                ) {
                    xArray.push(x);
                    yArray.push(y);

                    //transform and generate transArrays.
                    let xTransformed = x1 * x + y1 * y;
                    let yTransformed = x2 * x + y2 * y;

                    xArrayTrans.push(xTransformed);
                    yArrayTrans.push(yTransformed);
                }
            }
            let inputArray = numeric.linspace(-lineLength, lineLength, 10);

            for (let i = 0; i < inputArray.length; i++) {
                let x = inputArray[i] * Math.cos(inputTheta);
                let y = inputArray[i] * Math.sin(inputTheta);
                xInput.push(x);
                yInput.push(y);

                //transform and generate transArrays.
                let xInputTransformed = x1 * x + y1 * y;
                let yInputTransformed = x2 * x + y2 * y;

                xInputTransformedArray.push(xInputTransformed);
                yInputTransformedArray.push(yInputTransformed);
            }
            return ([xInput, yInput, xArray, yArray, lineLength, xInputTransformedArray, yInputTransformedArray, theta0, theta1, newTheta, xArrayTrans, yArrayTrans]);
        }


        // Now begins the Interactivity Segment of the code

        // define constants related to animation time
        const animate_time = 10;
        const total_animate_time = 400;
        const t = animate_time / total_animate_time;
        let counter = 0;
        let ispaused = true;
        let animator;

        let slider = vm.slider*Math.PI/180;

        //Layout object for plotly
        const layout = {
            autosize: true,
            margin: {
                l: 20,
                r: 20,
                t: 20,
                b: 20
            },
            hovermode: "closest",
            showlegend: true,
            legend: {
                orientation: "v",
                x:0,
                y:1,
            },
            xaxis: {
                constrain: 'domain',
                label: "x",
            },
            yaxis: {
                label: "y",
                scaleanchor: "x",
            },
        };

        //function takes all relevant vector and posisitions as inputs and uses plotly to create plots.
        function graph([xInput, yInput, xArray, yArray, lineLength, xInputTransformedArray, yInputTransformedArray, theta0, theta1, newTheta, xArrayTrans, yArrayTrans]) { // eslint-disable-line no-unused-vars
            let inputTheta = vm.slider * Math.PI/180;
            //define input matrix:
            let data = [
                {
                    x: xArray,
                    y: yArray,
                    type: "scatter",
                    opacity: "0.5",
                    name: "General Positions",
                    mode: "markers",
                    hovertext: "2D array",
                    marker: {
                        color: "#9D9D9D"
                    }
                },
                {
                    x: [-lineLength * math.cos(theta0), lineLength * math.cos(theta0)],
                    y: [-lineLength * math.sin(theta0), lineLength * math.sin(theta0)],
                    name: "Eigenvector 1",
                    type: "scatter",
                    mode: "lines",
                    hovertext: "Eigenvector 1",
                    marker: {
                        color: "#02893B",
                    }
                },

                {
                    x: [-lineLength * math.cos(theta1), lineLength * math.cos(theta1)],
                    y: [-lineLength * math.sin(theta1), lineLength * math.sin(theta1)],
                    name: "Eigenvector 2",
                    type: "scatter",
                    mode: "lines",
                    hovertext: "Eigenvector 2",
                    marker: {
                        color: "#EC7300",
                    }
                },
                {
                    x: [
                        -lineLength * math.cos(inputTheta),
                        lineLength * math.cos(inputTheta)
                    ],
                    y: [
                        -lineLength * math.sin(inputTheta),
                        lineLength * math.sin(inputTheta)
                    ],
                    name: "Probing line",
                    type: "scatter",
                    mode: "lines",
                    marker: {
                        color: "#751E66"
                    }
                },
                {
                    x: xInput,
                    y: yInput,
                    type: "scatter",
                    mode: "markers",
                    name: "Probe Positions",
                    hovertext: "Position vectors",
                    marker: {
                        color: "0091D4"
                    }
                }

            ];

            Plotly.react("graph", data, layout);
        }



        // function calls maths function using jQuery slider/input values, and uses these to plot the graphs
        function updatePlot() {
            customMatrix(vm.M0, vm.M1, vm.M2, vm.M3);
            data_for_plotting = calculate_positions_and_vectors(slider, vm.M0, vm.M1, vm.M2, vm.M3);
            graph(data_for_plotting);

        }



        //Start animation is called when the apply transformation button is clicked. This function starts animating the point traces using native JS setInterval()
        let data_for_plotting = calculate_positions_and_vectors(slider, vm.M0, vm.M1, vm.M2, vm.M3);
        function startAnimation() {
            // reset counter to 0 (restart animation)
            counter = 0;
            // calculate and define pre and post transformed data
            data_for_plotting = calculate_positions_and_vectors(slider, vm.M0, vm.M1, vm.M2, vm.M3);
            const xInput = data_for_plotting[0];
            const yInput = data_for_plotting[1];
            const xArray = data_for_plotting[2];
            const yArray = data_for_plotting[3];
            const xInputTransformedArray = data_for_plotting[5];
            const yInputTransformedArray = data_for_plotting[6];
            const xArrayTrans = data_for_plotting[10];
            const yArrayTrans = data_for_plotting[11];
            // initialise the difference arrays, which are the difference between the before and after transformation data
            let xprobedifference = copy(xInput);
            let yprobedifference = copy(yInput);
            let xgeneraldifference = copy(xArray);
            let ygeneraldifference = copy(yArray);
            // fill the difference arrays with th
            for (let i = 0; i < xInput.length; i++) {
                xprobedifference[i] = xInputTransformedArray[i] - xInput[i];
                yprobedifference[i] = yInputTransformedArray[i] - yInput[i];
            }
            for (let i = 0; i < xArray.length; i++) {
                xgeneraldifference[i] = xArrayTrans[i] - xArray[i];
                ygeneraldifference[i] = yArrayTrans[i] - yArray[i];
            }
            animator = setInterval(Animate, animate_time, xInput, yInput, xprobedifference, yprobedifference, xArray, yArray, xgeneraldifference, ygeneraldifference);
        }


        function Animate(xprobe, yprobe, xdiff_probe, ydiff_probe, xarrayall, yarrayall, xdiff_general, ydiff_general) {
            if (!ispaused) {
                for (let i = 0; i < xprobe.length; i++) {
                    xprobe[i] += t * xdiff_probe[i];
                    yprobe[i] += t * ydiff_probe[i];
                }
                for (let i = 0; i < xarrayall.length; i++) {
                    xarrayall[i] += t * xdiff_general[i];
                    yarrayall[i] += t * ydiff_general[i];
                }

                Plotly.restyle("graph", {
                    x: [xarrayall, xprobe],
                    y: [yarrayall, yprobe],
                }, [0, 4]);

                counter += t;
                if (counter >= 1) {
                    clearInterval(animator);
                    vm.buttonText = "Apply";
                    vm.buttonActive = false;
                    vm.isPlaying = false;
                }
            }
        }

        // find eigenvectors and eigenvalues from an inputted matrix, then update the correspoinding eigenvector html
        function customMatrix(a, c, b, d) {
            let matrix = [[a, b], [c, d]];
            let xEigVector0 = 2 * math.round(numeric.eig(matrix).E.x[0][0] * 100) / (100);
            let yEigVector0 = 2 * math.round(numeric.eig(matrix).E.x[1][0] * 100) / (100);
            let eigenvalue0 = math.round(numeric.eig(matrix).lambda.x[0] * 100) / 100;

            let xEigVector1 = 2 * math.round(numeric.eig(matrix).E.x[0][1] * 100) / (100);
            let yEigVector1 = 2 * math.round(numeric.eig(matrix).E.x[1][1] * 100) / (100);
            let eigenvalue1 = math.round(numeric.eig(matrix).lambda.x[1] * 100) / 100;

            vm.eigenvector1 = "(" + xEigVector0 + "," + yEigVector0 + ")";
            vm.eigenvector2 = "(" + xEigVector1 + "," + yEigVector1 + ")";
            vm.eigenvalue1 = eigenvalue0;
            vm.eigenvalue2 = eigenvalue1;
        }

        // function that updates all plots and resets the animator
        function inputupdate() {
            requestAnimationFrame(inputupdate);

            if(vm.reset){
                vm.redraw = true;
                vm.reset = false;
            }

            if(vm.redraw){
                slider = vm.slider *Math.PI/180;
                clearInterval(animator);
                counter = 0;
                $("#animator").html("Apply Transformation");
                updatePlot();
                vm.redraw = false;
            }

            if(vm.isPlaying && vm.buttonText == "Apply"){
                ispaused = false;
                startAnimation();
                vm.buttonText = "Pause";
            }
            else if(!vm.isPlaying && vm.buttonText == "Pause"){
                ispaused = true;
                vm.buttonText = "Resume";
            }
            else if(vm.isPlaying && vm.buttonText == "Resume"){
                vm.buttonText = "Pause";
                ispaused = false;
            }

        }

        //plot a new empty plot in the graph div, then call the update function
        let dummy;
        Plotly.newPlot("graph", dummy);
        inputupdate();
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
td {
  padding: 12px 15px;
  text-align: right;
  border-bottom: 1px solid #E1E1E1; }
tr > th:first-child{
  text-align: left;
}
tr > td:first-child{
  text-align: left;
}
table.matrix{
  text-align: center;
  border: solid 2px #000;
  position: relative;
  display: inline-block;
  margin-bottom: 0;
}
table.matrix::before{
  content: " ";
  display: block;
  z-index: 100;
  position: absolute;
  left: 50%;
  top: 0;
  background-color: #fff;
  width: 86%;
  margin-left: -43%;
  margin-top: -2px;
  height: 4px;
}
table.matrix::after{
  content: " ";
  display: block;
  z-index: 100;
  position: absolute;
  left: 50%;
  bottom: 0;
  background-color: #fff;
  width: 86%;
  margin-left: -43%;
  margin-bottom: -2px;
  height: 4px;

}
table.matrix th,
table.matrix td {
  padding: 10px 10px;
  text-align: center;
  border-bottom: none;
  font-weight: 700;
}
table.matrix th {
  /*border-top: 1px solid #E1E1E1; */
/*  -webkit-box-shadow: 0px 2px 2px 0px rgba(0,0,0,0.1);
  -moz-box-shadow: 0px 2px 2px 0px rgba(0,0,0,0.1);
  box-shadow: 0px 2px 2px 0px rgba(0,0,0,0.1);*/
}
table.matrix th:first-child,
table.matrix td:first-child {
  padding: 10px; }
table.matrix th:last-child,
table.matrix td:last-child {
  padding: 10px; }
table.matrix tr > th:first-child{
  text-align: center;
}
table.matrix tr > td:first-child{
  text-align: center;
}


table.matrixWrapper{
}
table.matrixWrapper>tbody>tr>th,
table.matrixWrapper>tbody>tr>td {
  padding: 0;
  margin: 0;
  text-align: center;
  border: none;
  font-weight: normal;
}
table.matrixWrapper>tbody>tr>th:first-child,
table.matrixWrapper>tbody>tr>td:first-child {
  padding: 0; }
table.matrixWrapper>tbody>tr>th:last-child,
table.matrixWrapper>tbody>tr>td:last-child {
  padding: 0; }
</style>